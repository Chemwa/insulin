import re
# Specify the input file path
input_file_path = 'prepoin-seq.txt'  # Replace with your actual file path
output_file_path = 'prepro-clean.txt' # Path to save the cleaned sequence

# Read the file contents
with open(input_file_path, 'r') as file:
    sequence = file.read()

# Use regex to clean the data:
# 1. Remove numbers and slashes (//).
# 2. Remove extra spaces or line breaks.
cleaned_sequence = re.sub(r'[\d\s//]', '', sequence)

# Write the cleaned sequence to a new file
with open(output_file_path, 'w') as cleaned_file:
    cleaned_file.write(cleaned_sequence)

print("Sequence cleaned and saved to", output_file_path)

